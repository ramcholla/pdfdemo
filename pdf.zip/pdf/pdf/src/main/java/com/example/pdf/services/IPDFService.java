package com.example.pdf.services;

import java.util.List;

import com.example.pdf.model.Account;

public interface IPDFService {

	List<Account> generatePlainPdf(List<Account> acc);

}
