package com.example.pdf.services;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.pdf.model.Account;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Header;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class PDFServiceImpl implements IPDFService{

	@Override
	public List<Account> generatePlainPdf( List<Account> acc) {
		// TODO Auto-generated method stub
		//plain pdf code
		// writeFile(new Document(), acc);
		
		//color pdf code
		Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(("D://AngularMaterial/plain.pdf")));
        } catch (DocumentException | FileNotFoundException e) {
        	System.out.println("Error Getting Document Instance");
        }
        document.open();
        try {
        	Font font2 = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.RED);
            Chunk chunk = new Chunk("Account Details using IText PDF doc", font2);
            document.add(chunk);
            
            Font font = FontFactory.getFont(FontFactory.COURIER, 14, BaseColor.BLUE);
            System.out.println("size---"+acc.size());
        	for(Account accList:acc) {
        		document.add(new Paragraph("Account Name-->"+accList.getAccName()+"  Account No-->"+accList.getAccNo()+"  Bank Name-->"+accList.getBankName(),font));
        	}
            
            //document.add(new Paragraph(p_Text, font));

            
        } catch (DocumentException e) {
        	System.out.println("Error Modify Document");
        }
        document.close();
		return acc;
	}
	//plain pdf document
	private void writeFile(Document p_Document, List<Account> acc) {
        try {
            PdfWriter.getInstance(p_Document, new FileOutputStream(("D://AngularMaterial/plain.pdf")));
        } catch (DocumentException | FileNotFoundException e) {
            System.out.println("Error Getting Document Instance");
        }
        p_Document.open();
        try {
        	System.out.println("size---"+acc.size());
        	for(Account accList:acc) {
        		p_Document.add(new Paragraph("Account Name-->"+accList.getAccName()+"  Account No-->"+accList.getAccNo()+"  Bank Name-->"+accList.getBankName()));
        	}
            
            
        } catch (DocumentException e) {
        	System.out.println("Error Modify Document");
        }
        p_Document.close();
    }
	

}
