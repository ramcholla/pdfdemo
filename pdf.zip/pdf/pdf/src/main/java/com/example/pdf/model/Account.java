package com.example.pdf.model;


public class Account {


	private String accName;
	private int accNo;
	private String bankName;
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	@Override
	public String toString() {
		return "Account [accName=" + accName + ", accNo=" + accNo + ", bankName=" + bankName + "]";
	}
	public Account(String accName, int accNo, String bankName) {
		super();
		this.accName = accName;
		this.accNo = accNo;
		this.bankName = bankName;
	}
	public Account() {
		
	}
	public static void add(Account account) {
		// TODO Auto-generated method stub
		
	}


}
