package com.example.pdf.rest;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pdf.model.Account;
import com.example.pdf.services.IPDFService;

@RestController
public class PDFRestController {
	
	@Autowired
	private IPDFService pdfService; 
	
	@GetMapping(value="/pdf",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Account>> getDetails() {
		List<Account> acclt=new ArrayList<Account>();
		Account acc=new Account();
		acc.setAccName("Rams");
		acc.setAccNo(34324243);
		acc.setBankName("SBI");
		Account acc1=new Account();
		acc1.setAccName("Chinna");
		acc1.setAccNo(7856489);
		acc1.setBankName("ICICI");
		acclt.add(acc);
		acclt.add(acc1);
		List<Account> lt=pdfService.generatePlainPdf(acclt);
		
		return new ResponseEntity<List<Account>>(lt,HttpStatus.OK);
	}

}
